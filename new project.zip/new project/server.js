const express = require('express');
const path = require('path');
const mysql = require('mysql2');
const loginRoutes = require('./login'); // Import login routes
const app = express();
const PORT = process.env.PORT || 3000;

// Set up middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public'))); // Serve static files

// Use login routes
app.use('/', loginRoutes);

// Create a MySQL connection pool
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '1234',
    database: 'file_sharing_db'
});

// Route to serve admin page (admin.html)
app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'admin.html')); // Serve from 'views' folder
});

// Serve HTML for uploads
app.get('/uploads', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'upload.html')); // Serve upload.html
});

// Serve HTML for access
app.get('/access', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'access.html')); // Serve access.html
});

// Serve HTML for admin login
app.get('/adminlogin', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'Adlog.html')); // Serve admin login page
});



// Route to fetch data for the admin dashboard with filters
app.get('/data', (req, res) => {
    const { fileName, dateFilter } = req.query;

    let sql = 'SELECT * FROM admin WHERE 1=1';

    if (fileName) {
        sql += ` AND file_name LIKE '%${fileName}%'`;
    }
    if (dateFilter) {
        sql += ` AND DATE(date) = '${dateFilter}'`;
    }

    pool.query(sql, (err, results) => {
        if (err) {
            console.error('Error fetching data:', err);
            return res.status(500).send('Error fetching data');
        }

        let html = '';
        results.forEach((row, index) => {
            html += `
            <tr>
                <td>${index + 1}</td>
                <td>${row.file_name}</td>
                <td>${row.access_code}</td>
                <td>${row.date}</td>
                <td>${row.time}</td>
                <td><a href="#" class="preview-btn">Preview</a></td>
            </tr>`;
        });

        res.send(html);
    });
});




// Start the server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});



