const express = require('express');
const multer = require('multer');
const QRCode = require('qrcode');
const mysql = require('mysql2');
const path = require('path');

const app = express();
const PORT = 3000;

// Serve static files
app.use(express.static('public'));

// Set up multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, './uploads'); // Save files to 'uploads' folder
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ storage });

// MySQL connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '1234', // Replace with your MySQL password
  database: 'file_sharing_db' // Replace with your database name
});

db.connect((err) => {
  if (err) throw err;
  console.log('Connected to MySQL Database.');
});

// Handle file upload and save details to database
app.post('/upload', upload.single('file'), (req, res) => {
  const accessCode = Math.floor(1000 + Math.random() * 9000).toString();
  const fileName = req.file.filename;
  const filePath = req.file.path;
  const uploadDateTime = new Date().toISOString().slice(0, 19).replace('T', ' ');

  const sql = 'INSERT INTO files (access_code, file_name, file_path, upload_datetime) VALUES (?, ?, ?, ?)';
  db.query(sql, [accessCode, fileName, filePath, uploadDateTime], (err, result) => {
    if (err) throw err;

    QRCode.toDataURL(`http://localhost:${PORT}/access/${accessCode}`, (err, url) => {
      if (err) return res.status(500).send('Error generating QR code');

      res.json({
        message: 'File uploaded successfully',
        accessCode,
        qrCode: url
      });
    });
  });
});

// Handle file access by access code
app.get('/access/:code', (req, res) => {
  const accessCode = req.params.code;

  const sql = 'SELECT * FROM files WHERE access_code = ?';
  db.query(sql, [accessCode], (err, results) => {
    if (err) throw err;

    if (results.length > 0) {
      const file = results[0];
      res.json({
        message: 'File accessed successfully',
        fileName: file.file_name,
        uploadDateTime: file.upload_datetime,
        downloadUrl: `/download/${accessCode}`
      });
    } else {
      res.status(404).send('Invalid access code');
    }
  });
});

// Serve the file for download
app.get('/download/:code', (req, res) => {
  const accessCode = req.params.code;

  const sql = 'SELECT file_path FROM files WHERE access_code = ?';
  db.query(sql, [accessCode], (err, results) => {
    if (err) throw err;

    if (results.length > 0) {
      const filePath = results[0].file_path;
      res.download(filePath);
    } else {
      res.status(404).send('File not found');
    }
  });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
