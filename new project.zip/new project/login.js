const express = require('express');
const path = require('path');
const session = require('express-session');

const router = express.Router();

// Sample credentials
const validEmail = 'shrikant@gmail.com';
const validPassword = '12345';

// Session setup (ensure this is consistent with your main file)
router.use(session({
    secret: 'secret-key', // Use a strong secret key in production
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Set to true if using HTTPS
}));

// Serve admin login page
router.get('/adminlogin', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'Adlogin.html')); // Serve admin login page
});

// Handle login
router.post('/Admin', (req, res) => {
    const { email, password } = req.body;

    // Check if credentials are correct
    if (email === validEmail && password === validPassword) {
        req.session.isAuthenticated = true;  // Set session for authenticated user
        res.redirect('/admin'); // Redirect to admin page after login
    } else {
        res.redirect('/login-error'); // Redirect to error page
    }
});

// Handle login error
router.get('/login-error', (req, res) => {
    res.send(`
        <script>
            alert("Invalid email or password!");
            window.location.href = "/adminlogin"; // Redirect to the login page
        </script>
    `);
});

// Serve admin page
router.get('/admin', (req, res) => {
    if (req.session.isAuthenticated) {
        res.sendFile(path.join(__dirname, 'views', 'admin.html')); // Serve the admin page
    } else {
        res.redirect('/'); // Redirect to login page if not authenticated
    }
});

// Logout route
router.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.status(500).send('Error logging out.');
        }
        res.clearCookie('connect.sid'); // Clear the session cookie
        res.redirect('/'); // Redirect to login page after logout
    });
});

// Check authentication for admin page
router.get('/admin/check-auth', (req, res) => {
    if (req.session.isAuthenticated) {
        res.status(200).send('Authenticated');
    } else {
        res.status(401).send('Unauthorized');
    }
});

module.exports = router;
