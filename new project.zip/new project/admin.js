// Import necessary modules
const express = require('express');
const mysql = require('mysql2');
const path = require('path');

// Create an Express app
const app = express();

// Set the port to listen on
const PORT = 3000;

// Serve static files from the 'public' folder
app.use(express.static(path.join(__dirname, 'public')));

// Create a MySQL connection pool
const pool = mysql.createPool({
    host: 'localhost',  // Your MySQL host (localhost if running locally)
    user: 'root',       // MySQL username
    password: '1234',       // MySQL password (leave empty if there's none)
    database: 'file_sharing_db'  // Your MySQL database name
});

// Step 1: Serve the index.html file on the root URL
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));  // Path to your index.html file in the public folder
});

// Step 2: Create route to fetch data from MySQL
app.get('/data', (req, res) => {
    pool.query('SELECT * FROM admin', (err, results) => {
        if (err) {
            console.error('Error fetching data:', err);
            return res.status(500).send('Error fetching data');
        }

        // Generate table rows dynamically
        let html = '';
        results.forEach(row => {
            html += `
            <tr>
                <td>${row.serial_number}</td>
                <td>${row.file_name}</td>
                <td>${row.access_code}</td>
                <td>${row.date}</td>
                <td>${row.time}</td>
                <td>${row.preview_section}</td>
            </tr>`;
        });

        // Send the HTML rows to the client
        res.send(html);
    });
});

// Step 3: Start the server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
